// import './scss/reset.scss'
// import './scss/classes.scss'
import './scss/style.scss'



//posters toggle

//1й))

// let posterBtn = document.querySelector('.poster-btn')
// let posterBtnActive = document.querySelector('.poster-active')

// posterBtn.onclick = function(){
//     posterBtn.classList.remove('poster-active');
// }


//2 вариант

// let posterBtns = document.querySelectorAll('.poster-btn');

// posterBtns.forEach(function(btn) {
//   btn.addEventListener('click', function() {
//     // Проверяем, активна ли кнопка
//     if (!this.classList.contains('poster-active')) {
//       // Если не активна, удаляем класс 'poster-active' со всех кнопок
//       posterBtns.forEach(function(button) {
//         button.classList.remove('poster-active');
//       });
//       // Затем добавляем класс 'poster-active' только к текущей нажатой кнопке
//       this.classList.add('poster-active');
//     }
//   });
// });

let posterBtns = document.querySelectorAll('.poster-btn');

posterBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    // Проверяем, активна ли кнопка
    if (!this.classList.contains('poster-active')) {
      // Если не активна, удаляем класс 'poster-active' со всех кнопок
      posterBtns.forEach(function(button) {
        button.classList.remove('poster-active');
      });
      // Затем добавляем класс 'poster-active' только к текущей нажатой кнопке
      this.classList.add('poster-active');
      
      // Получите все изображения
      let images = Array.from(document.querySelectorAll('.soon-posters-imgs img'));

      // Переключите порядок изображений
      images = images.reverse();

      // Удалите все изображения из контейнера
      let postersContainer = document.querySelector('.soon-posters-imgs');
      images.forEach(img => postersContainer.removeChild(img));

      // Добавьте изображения в обратном порядке
      images.forEach(img => postersContainer.appendChild(img));
    }
  });
});


//slider

const swiper = new Swiper('.swiper', {
    // Optional parameters
    direction: 'horizontal',
    loop: false,
    speed: 1300,
    autoplay: {
      delay: 5000,
    },

    // If we need pagination
    pagination: {
      el: '.swiper-pagination',
    },
  
    // Navigation arrows
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
  
    // And if we need scrollbar
    scrollbar: {
      el: '.swiper-scrollbar',
    },

  });


